<?php
session_name('iniciar');
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSSagenda/login.css">
</head>
<body>
<form method="post" action="login.php">

    <div class="container">
        <div class="input-group">
            <label for="name">Nome:</label><br>
            <input type="text" id="name" name="name" required><br>
        </div>

        <div class="input-group">
            <label for="password">Senha:</label><br>
            <input type="password" id="password" name="password" required>
        </div>

        <button type="submit" name="Entrar">Entrar</button>
        <button id="botao" type="button" onclick="window.location.href='usuarioInsert.php'">Cadastrar</button>
    </div>

</form> 
</body>
</html>

<?php

extract($_POST);

if (isset($_POST["Entrar"])) {
    include_once("conect.php");
    $obj = new conect();
    $resultado = $obj->conectarBanco();
        
    $sql = "SELECT id, nomeUsuario, senha FROM Usuario WHERE nomeUsuario = :nome AND senha = :senha";
    $query = $resultado->prepare($sql);
    
    $query->bindValue(':nome', $_POST["name"]);
    $query->bindValue(':senha', md5($_POST["password"]));

    $indice = 0;
    
    if ($query->execute()) {
        
        while ($linha = $query->fetch(PDO::FETCH_ASSOC)) {
            $linhas[$indice] = $linha;
            $indice++;
        }
        
        if ($indice == 1) {
            $_SESSION["cadastro"] = TRUE;
            $_SESSION["id"] = $linhas[0]["id"];
            header("location: AgendaContatosSelect.php");
        } else {
            echo "<script>alert('Usuário e senha não existem, verifique!');</script>";

            $nomeArquivo = 'logs/log.txt';

            $arquivo = fopen($nomeArquivo, 'a+');

            if ($arquivo) {
                $conteudo = "\nTentativa de login falhada:\n";
                $conteudo .= "Data: " . date('d/m/y') . "\n";
                $conteudo .= "Usuário: " . $_POST["name"] . "\n";
                $conteudo .= "Senha: " . $_POST["password"] . "\n"; 
                $conteudo .= "IP: " . $_SERVER['REMOTE_ADDR'] . "\n";
                fwrite($arquivo, $conteudo);
                fclose($arquivo);
            }
        }
    }
}

unset($sql, $query);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Atualizar Usuario</title>
    <link rel="stylesheet" href="CSSagenda/UsuarioUpdate.css">

</head>
<body>
    <form action="contatosUpdate.php" method="post">
        <input type="text" name="nomeUsuario" placeholder="nomeUsuario" required>
        <input type="text" name="senha" placeholder="senha" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="text" name="login" placeholder="login" required>
        <button type="submit" name="update_contato">Atualizar Usuario</button>
        <a href="AgendaUsuariosSelect.php"><button type="button" name="voltar">Voltar</button></a>

    </form>
</body>
</html>

<?php

include_once("conect.php");
$obj = new conect();
$resultado = $obj->conectarBanco();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_contato'])) {
    $id = $_POST['id'];
    $nomeUsuario = $_POST['nomeUsuario'];
    $senha = $_POST['senha'];
    $email = $_POST['email'];
    $login = $_POST['login'];
 
    echo $sql = "UPDATE Contatos SET nomeUsuario='".$_POST["nomeUsuario"]."',senha='".$_POST["senha"]."',email='".$_POST["email"]."',login='".$_POST["login"]."' WHERE id=".$id.";";
    $executado = $resultado->prepare($sql);
    $executado->execute();

    echo "Contato atualizado com sucesso!";
    exit();
}
?>

<?php
    session_name('iniciar');
    session_start();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atualizar Contato</title>
    <link rel="stylesheet" href="../CSSagenda/usuarioInsert.css">

</head>

<body>

<div class="container">
    <form method="post" action="usuarioInsert.php">
        <div class="input-group">
            <label for="NomeUsuario">Nome de Usuário:</label>
            <input type="text" id="NomeUsuario" name="NomeUsuario" required>
        </div>

        <div class="input-group">
            <label for="senha">Senha:</label>
            <input type="password" id="senha" name="senha" required>
        </div>

        <div class="input-group">
            <label for="email">Email:</label>
            <input type="text" id="email" name="email" required>
        </div>

        <div class="input-group">
            <label for="login">Login:</label>
            <input type="text" id="login" name="login" required>
        </div>

        <button type="submit" name="enviar">Enviar</button>
        <div style="margin-top: 15px;">
            <a href="login.php"><button type="button" class="botao2" >Voltar para Login</button></a>
        </div>
    </form>
</div>

</body>
</html>

<?php

extract($_POST);

if (isset($_POST["enviar"])) {
    include_once("conect.php");
    $obj = new conect();
    $resultado = $obj->conectarBanco();

    $senhacriptografado1 = md5($_POST["senha"]);
    $logincriptografado1 = md5($_POST["login"]);

    $sql = "INSERT INTO Usuario (NomeUsuario, senha, email, login, ativo) VALUES ('".$_POST["NomeUsuario"]."', '".$senhacriptografado1."', '".$_POST["email"]."', '".$logincriptografado1."', TRUE);";

    $query = $resultado->prepare($sql);
    if ($query->execute()) {
        echo "<script>alert('Usuario cadastrado!'); window.location.href='login.php';</script>";
    } else {
        echo "<script>alert('Erro ao cadastrar.');</script>";
    }
}
unset($_POST["enviar"], $_POST["NomeUsuario"], $_POST["senha"], $_POST["email"], $_POST["login"]);
?>

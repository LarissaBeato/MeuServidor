<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSSagenda/chat_refresh.css">
    <title>Document</title>
</head>
<body>
    
</body>
</html>

<?php
    include_once("conect.php");
    $obj = new conect();
    $resultado = $obj->conectarBanco();

    $sql = "SELECT * FROM chat ORDER BY id_chat;";
    $query = $resultado->prepare($sql);
    
    function gerarCor($nome) {
        $hash = md5($nome);
        return '#' . substr($hash, 0, 6);
    }

    if ($query->execute()) {
        while ($linha = $query->fetch(PDO::FETCH_ASSOC)) {
            $corUsuario = gerarCor($linha['nome']);
            echo "<h3 style='color: {$corUsuario};'>" . htmlspecialchars($linha['nome']) . "</h3>";
            echo "<p>" . htmlspecialchars($linha['msg']) . "</p>";
        }
    }
?>

<?php
session_name('iniciar');
session_start();

if ($_SESSION['cadastro'] == FALSE) {
    session_destroy();
    header("location: login.php");
    exit();
}
?>

<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Contatos</title>
    <link rel="stylesheet" href="../CSSagenda/contatosInsert.css">
</head>
<body>

<div class="container">
    <form method="post" action="contatosInsert.php" enctype="multipart/form-data">
        <label for="name">Nome:</label>
        <input type="text" id="name" name="name" required>
        
        <label for="endereco">Endereço:</label>
        <input type="text" id="endereco" name="endereco" required>
        
        <label for="email">Email:</label>
        <input type="text" id="email" name="email" required>
        
        <label for="telefone">Telefone:</label>
        <input type="text" id="telefone" name="telefone" required>
        
        <label for="celular">Celular:</label>
        <input type="text" id="celular" name="celular" required>
        
        <label for="foto">Foto de Perfil</label>
        <input type="file" name="arquivo">
        
        <button type="submit" id="botaoEnviar" name="Entrar">Enviar</button>
    </form>

    <form action="AgendaContatosSelect.php" method="post">
        <button id="botaoVoltar" type="submit" name="voltar">Voltar</button>
    </form>
</div>

</body>
</html>

<?php

if (isset($_POST["Entrar"])) {
    include_once("conect.php");
    $obj = new conect();
    $resultado = $obj->conectarBanco();

    $email = $_POST["email"];
    $sqlCheck = "SELECT COUNT(*) FROM Contatos WHERE email = :email AND contatos_idfk = :contatos_idfk";
    $queryCheck = $resultado->prepare($sqlCheck);
    $queryCheck->execute([':email' => $email, ':contatos_idfk' => $_SESSION["id"]]);
    $emailExists = $queryCheck->fetchColumn();

    if ($emailExists > 0) {
        echo "<script>alert('Este e-mail já está cadastrado!');</script>";
    } else {
        $destino = 'imgPerfil/' . $_FILES['arquivo']['name'];
        $arquivo_tmp = $_FILES['arquivo']['tmp_name'];
        move_uploaded_file($arquivo_tmp, $destino);

        $sql = "INSERT INTO Contatos (imagem, nome, endereco, email, telefone, celular, contatos_idfk) VALUES (:imagem, :nome, :endereco, :email, :telefone, :celular, :contatos_idfk)";
        $query = $resultado->prepare($sql);

        $query->bindParam(':imagem', $destino);
        $query->bindParam(':nome', $_POST["name"]);
        $query->bindParam(':endereco', $_POST["endereco"]);
        $query->bindParam(':email', $_POST["email"]);
        $query->bindParam(':telefone', $_POST["telefone"]);
        $query->bindParam(':celular', $_POST["celular"]);
        $query->bindParam(':contatos_idfk', $_SESSION["id"]);

        if ($query->execute()) {
            echo "<script>alert('Cadastro realizado com sucesso!');</script>";
        } else {
            echo "<script>alert('Erro ao cadastrar!');</script>";
        }
    }

    unset($_POST["Entrar"], $_POST["name"], $_POST["endereco"], $_POST["email"], $_POST["telefone"], $_POST["celular"]);
}
?>

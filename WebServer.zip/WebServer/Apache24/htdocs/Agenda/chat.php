<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSSagenda/chat.css">
    <title>Chat</title>
    <script type="text/javascript">
        var userColors = {}; // Objeto para armazenar cores de usuários

        function getUserColor(nome) {
            // Se a cor já foi gerada, retorne-a
            if (userColors[nome]) {
                return userColors[nome];
            }
            // Gera uma cor aleatória
            const color = `hsl(${Math.random() * 360}, 100%, 50%)`;
            userColors[nome] = color; // Armazena a cor para o usuário
            return color;
        }

        function ajax() {
            var req = new XMLHttpRequest();
            req.onreadystatechange = function() {
                if(req.readyState === 4 && req.status === 200) {
                    document.getElementById('chat').innerHTML = req.responseText;
                }
            };
            req.open('GET', 'chat_refresh.php', true);
            req.send();
        }
        setInterval(ajax, 1000);

        function enviarMensagem(event) {
            event.preventDefault(); 

            var nome = document.getElementById('name').value;
            var mensagem = document.getElementById('msg').value;
            
            if (nome.trim() === '' || mensagem.trim() === '') return; 

            var color = getUserColor(nome); // Obtém a cor do usuário
            document.getElementById('chat').innerHTML += `<h3 style="color: ${color};">${nome}</h3><p>${mensagem}</p>`;
            
            document.getElementById('msg').value = '';

            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'chat.php', true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    ajax();
                }
            };
            xhr.send(`name=${encodeURIComponent(nome)}&msg=${encodeURIComponent(mensagem)}`);
        }
    </script>
</head>

<body>
    
    <div id="chat" style="border: solid 1px;"></div>

    <form onsubmit="enviarMensagem(event)">
        <div>
            <label for="name">Nome:</label>
            <input type="text" id="name" name="name" required>
            <br /><br />
            <label for="msg">Mensagem:</label>
            <input type="text" id="msg" name="msg" required>
            <button id="button" type="submit">Enviar</button>
        </div>

        <div>
        <button id="botao-voltar" type="button" onclick="window.location.href='AgendaContatosSelect.php'">Voltar</button>
        </div>
    </form>
</body>
</html>

<?php
include_once("conect.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['name']) && isset($_POST['msg'])) {
    $obj = new conect();
    $resultado = $obj->conectarBanco();

    $sql = "INSERT INTO chat (nome, msg) VALUES (:name, :msg)";
    $query = $resultado->prepare($sql);
    $query->bindParam(':name', $_POST['name']);
    $query->bindParam(':msg', $_POST['msg']);

    if ($query->execute()) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error']);
    }
}
?>

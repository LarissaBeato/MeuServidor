function ajax() {
    var req = new XMLHttpRequest();
    req.onreadystatechange = function() {
        if (req.readyState == 4 && req.status == 200) {
            document.getElementById('chat').innerHTML = req.responseText;
        }
    };
    req.open('GET', 'chatRefresh.php', true);
    req.send(); // Certifique-se de enviar a requisição
}

// Chama a função ao carregar a página
window.onload = ajax;

// Atualiza a cada segundo
setInterval(ajax, 1000);


function NavBar() {
    document.getElementById('btn-menu').addEventListener('click', function() {
        var navLinks = document.getElementsByClassName('nav-link');

        for (var i = 0; i < navLinks.length; i++) {
            // Verifica se o estilo de exibição é 'none'
            if (navLinks[i].style.display === 'none' || navLinks[i].style.display === '') {
                navLinks[i].style.display = 'block'; // Mostra a barra de navegação
            } else {
                navLinks[i].style.display = 'none'; // Esconde a barra de navegação
            }
        }
    });
}

// Chame a função NavBar para inicializar
NavBar();
<?php
session_name('iniciar');
session_start();

if ($_SESSION['cadastro'] == FALSE) {
    session_destroy();
    header("location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../projeto/CSSprojeto/cadastro.css">
    <title>Cadastro</title>
</head>
<body>
    <header class ="cadastro"></header>

    <div class = "titulo">
        <h1>CADASTRO</h1>
    </div>

    <form method="post" action="login.php">
        <div class="container">
            <div class="input-group">
                <label for="nome">Nome Completo:</label><br>
                <input type="name" id="name" name="name" required><br>
            </div>
            
            <div class="input-group">
                <label for="telefone">Telefone:</label><br>
                <input type="tel" id="telefone" name="telefone" required>
            </div>

            <div class="input-group">
                <label for="cpf">CPF:</label><br>
                <input type="text" id="cpf" name="cpf" required>
            </div>

            <div class="input-group">
                <label for="email">Email:</label><br>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="input-group">
                <label for="password">Senha:</label><br>
                <input type="password" id="password" name="password" required>
            </div>

            <div class="input-group">
                <label for="password">Confirmar Senha:</label><br>
                <input type="password" id="password" name="password" required>
            </div>

            <button type="submit" onclick="window.location.href='login.php'" name="Entrar">Enviar</button>
            
        </div>

    </body>
</html>

<?php

if (isset($_POST["Entrar"])) {
    include_once("connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    
    $email = $_POST["email"];
    $sqlCheck = "SELECT COUNT(*) FROM Cadastro WHERE email = :email AND contatos_idfk = :contatos_idfk";
    $queryCheck = $resultado->prepare($sqlCheck);
    $queryCheck->execute([':email' => $email, ':contatos_idfk' => $_SESSION["id_user"]]);
    $emailExists = $queryCheck->fetchColumn();

    if ($emailExists > 0) {
        echo "<script>alert('Este e-mail já está cadastrado!');</script>";
    } else {

        $senhacriptografado = md5($_POST["senha"]);

        $destino = 'imgPerfil/' . $_FILES['arquivo']['name'];
        $arquivo_tmp = $_FILES['arquivo']['tmp_name'];
        move_uploaded_file($arquivo_tmp, $destino);

        $sql = "INSERT INTO Contatos (id_user, nomeCompleto, telefone, email, telefone, CPF, email, senha);
        $query = $resultado->prepare($sql);
        

        $query->bindParam(':id_user', $_SESSION["id_user"]);
        $query->bindParam(':nome', $_POST["name"]);
        $query->bindParam(':endereco', $_POST["endereco"]);
        $query->bindParam(':senha', $senhacriptografado);
        $query->bindParam(':email', $_POST["email"]);
        $query->bindParam(':telefone', $_POST["telefone"]);
        $query->bindParam(':celular', $_POST["celular"]);

        if ($query->execute()) {
            echo "<script>alert('Cadastro realizado com sucesso!');</script>";
        } else {
            echo "<script>alert('Erro ao cadastrar!');</script>";
        }
    }
    

    unset($_POST["Entrar"], $_POST["name"], $_POST["endereco"], $_POST["email"], $_POST["telefone"], $_POST["celular"]);
}
    



?>
<?php
session_name('iniciar');
session_start();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../projeto/CSSprojeto/login.css">
    <title>Login</title>
</head>
<body>
    <header class="login"></header>

    <div class="titulo">
        <h1>LOGIN</h1>
    </div>

    <form method="post" action="login.php">
        <div class="container">
            <div class="input-group">
                <label for="email">Email:</label><br>
                <i class='bx bxs-user-circle'></i>
                <input type="email" id="email" name="email" required><br>
            </div>
            
            <div class="input-group">
                <label for="password">Senha:</label><br>
                <i class='bx bxs-lock-alt'></i>
                <input type="password" id="password" name="password" required>
            </div>
            
            <a class="link" href="AgendaUsuariosSelect.php">Esqueci a senha</a>

            <button type="submit" name="Entrar">Entrar</button>
            <button type="button" onclick="window.location.href='cadastro.php'">Cadastrar</button>
        </div>
    </form>

    <?php if (isset($error_message)): ?>
        <div class="error"><?php echo htmlspecialchars($error_message); ?></div>
    <?php endif; ?>

    <footer></footer>
</body>
</html>

<?php

if (isset($_POST["Entrar"])) {
    include_once("conect.php");
    $obj = new conect();
    $resultado = $obj->conectarBanco();
        
    $sql = "SELECT id_login, email, senha FROM Login1 WHERE email = :email AND senha = :senha";
    $query = $resultado->prepare($sql);
    
    $query->bindValue(':email', $_POST["email"]);
    $query->bindValue(':senha', md5($_POST["password"]));

    $indice = 0;
    
    if ($query->execute()) {
        
        while ($linha = $query->fetch(PDO::FETCH_ASSOC)) {
            $linhas[$indice] = $linha;
            $indice++;
        }
        
        if ($indice == 1) {
            $_SESSION["Cadastro"] = TRUE;
            $_SESSION["id"] = $linhas[0]["id"];
            header("location: AgendaContatosSelect.php");
        } else {
            echo "<script>alert('Usuário e senha não existem, verifique!');</script>";

            $nomeArquivo = 'logs/log.txt';

            $arquivo = fopen($nomeArquivo, 'a+');

            if ($arquivo) {
                $conteudo = "\nTentativa de login falhada:\n";
                $conteudo .= "Data: " . date('d/m/y') . "\n";
                $conteudo .= "Usuário: " . $_POST["name"] . "\n";
                $conteudo .= "Senha: " . $_POST["password"] . "\n"; 
                $conteudo .= "IP: " . $_SERVER['REMOTE_ADDR'] . "\n";
                fwrite($arquivo, $conteudo);
                fclose($arquivo);
            }

        }
    }
}
unset($sql, $query);
?>


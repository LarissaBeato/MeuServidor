<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../projeto/CSSprojeto/pagInicial.css">
    <title>Página Inicial</title>
</head>
<body>
<header class="inicial"></header>

<div class="titulo">
    <h1>BEM-VINDO</h1>
</div>

<div class="login">
    <div class="login-box">
        <img src="curso.jpg" alt="Imagem de Login" class="login-image">
        <div class="login-content">
            <h2>Cursos</h2>
            <p><b>Investir em conhecimento é o caminho mais seguro para alcançar seus objetivos. Começar um curso hoje é plantar a semente do sucesso que você colherá amanhã!</b></p>
            <button class="login-button"onclick="window.location.href='cursos.php'">Clique Aqui</button>
        </div>
    </div>

    <div class="login-box">
        <img src="trabalho.webp" alt="Imagem de Login" class="login-image">
        <div class="login-content">
            <h2>Oportunidades de Trabalho</h2>
            <p><b>Cada pequeno passo dado hoje é uma construção sólida para o seu futuro. Não espere pelo momento perfeito, faça do agora a sua oportunidade de crescer e realizar!</b></p>
            <button class="login-button"onclick="window.location.href='vagas.php'">Clique Aqui</button>
        </div>
    </div>
    
</div>

<footer>
    <button class="sair" onclick="window.location.href='login.php'">Sair</button>
</footer>
    
</body>
</html>

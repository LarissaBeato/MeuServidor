<?php
    session_name('iniciar');
    session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSSagenda/login.css">

<body>
<form method="post" action="login.php">

    <div class="container">
        <div class="input-group">
            <label for="name">Nome:</label><br>
            <input type="text" id="name" name="name" required><br>
        </div>

        <div class="input-group">
            <label for="password">Senha:</label><br>
            <input type="password" id="password" name="password" required>
        </div>

        <button type="submit" name="Entrar">Entrar</button>
        <button id="botao" type="button" onclick="window.location.href='usuarioInsert.php'">Cadastrar</button>
    </div>
    <a class = "link" href = "AgendaUsuariosSelect.php">Pag. Usuarios</a>

</form> 

</body>
</head>
</html>

<?php

extract($_POST);

if (isset($_POST["Entrar"])) {
    include_once("conect.php");
    $obj = new conect();
    $resultado = $obj->conectarBanco();
        
    $sql = "SELECT id,nomeUsuario, senha FROM Usuario WHERE nomeUsuario = '".$_POST["name"]."' AND senha = '".md5($_POST["password"])."';";
    $query = $resultado->prepare($sql);
    
    $indice = 0;
    
    if ($query->execute()) {
        
        while ($linha = $query->fetch(PDO::FETCH_ASSOC)) {
            $linhas[$indice] = $linha;
            $indice++;
        }
        
        if ($indice == 1) {
            $_SESSION["cadastro"] = TRUE;
            $_SESSION["id"] = $linhas[0]["id"];
            header("location: AgendaContatosSelect.php");
        } else {
            echo "<script>alert('Usuário e senha não existem, verifique!');</script>";

            $nomeArquivo = 'logs/log.txt';

            $arquivo = fopen($nomeArquivo, 'a+');

            if($arquivo){
                $conteudo = "\nEste é um exemplo de escrita em um arquivo usando php\n";
                $conteudo .= date('d/m/y')."\n";
                $conteudo .= $_POST["name"]." - " .$_POST ["password"]."\n";

                fwrite($arquivo, $conteudo);
                fclose($arquivo);
            }
        }
    }
}

unset($sql, $query);

?>

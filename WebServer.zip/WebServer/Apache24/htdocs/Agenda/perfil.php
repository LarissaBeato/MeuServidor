<?php
session_name('iniciar');
session_start();

if ($_SESSION['cadastro'] == FALSE) {
    session_destroy();
    header("location: login.php");
    exit();
}

include_once("conect.php");
$obj = new conect();
$resultado = $obj->conectarBanco();

$sql = "SELECT nomeUsuario, email, login, imagem FROM Usuario WHERE id = :id";
$query = $resultado->prepare($sql);
$query->bindParam(':id', $_SESSION['id']);
$users = [];

if ($query->execute()) {
    $users[0] = $query->fetch(PDO::FETCH_ASSOC);
}

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="CSSagenda/perfil.css">
    <title>Página de Perfil da Agenda</title>
</head>
<body>

<header>
    <h1>Seu Perfil</h1>
</header>

<div class="container">
    <div class="container-info">
        <?php if (!empty($users[0]['imagem'])): ?>
            <img src="path/to/uploaded/images/<?= htmlspecialchars($users[0]['imagem']); ?>" alt="Imagem de Perfil" class="perfil-imagem">
        <?php else: ?>
            <i class='perfil bx bxs-user'></i>
        <?php endif; ?>
        <form method="POST" action="perfil.php" enctype="multipart/form-data">
        <input id="InputNome" name="nomeUsuario" type="text" placeholder="Nome Usuário" value="<?= $users[0]['nomeusuario'] ?>">
            <input id="InputEmail" name="email" type="text" placeholder="Email" value="<?= $users[0]['email'] ?>">
            <input id="InputLogin" name="login" type="text" placeholder="Login" value="<?= $users[0]['login'] ?>">
            <input id="InputImagem" name="imagem" type="file" placeholder="Imagem de Perfil">
            <button type="submit" name="update_contato" id="btn-edita">Salvar Informações</button>
            <button id="btn-edita" type="button" onclick="window.location.href='logoff.php'">Sair</button>
        </form>
    </div>
</div>

<footer>

</footer>

</body>
</html>

<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_contato'])) {
    $nomeUsuario = $_POST['nomeUsuario'];
    $email = $_POST['email'];
    $login = $_POST['login'];
    
    $imagem = $users[0]['imagem'];
    if (!empty($_FILES['imagem']['name'])) {
        $imagem = $_FILES['imagem']['name'];
       
    }
    
    $sqlUpdate = "UPDATE Usuario SET nomeUsuario = :nomeUsuario, email = :email, login = :login, imagem = :imagem WHERE id = :id";
    $queryUpdate = $resultado->prepare($sqlUpdate);
    $queryUpdate->bindParam(':nomeUsuario', $nomeUsuario);
    $queryUpdate->bindParam(':email', $email);
    $queryUpdate->bindParam(':login', $login);
    $queryUpdate->bindParam(':imagem', $imagem);
    $queryUpdate->bindParam(':id', $_SESSION['id']);

    if ($queryUpdate->execute()) {
        echo "<script>alert('Informações atualizadas com sucesso!');</script>";
    } else {
        echo "<script>alert('Erro ao atualizar as informações.');</script>";
    }
}

?>

<?php
session_name('iniciar');
session_start();

if ($_SESSION['cadastro'] == FALSE) {
    session_destroy();
    header("location: login.php");
    exit();
}
?> 

<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="CSSagenda/AgendaContatosSelect.css">
</head>
<body>

    <form action="AgendaContatosSelect.php" method="post">
        <div class="pesquisa">
            <input type="text" id="letra" name="letra" placeholder="Digite o nome...">
            <button id="botao1" type="submit" name="buscar">Buscar</button>
        </div>
        <table>
            <tr>
                <td colspan="2"><button id="botao" type="submit" name="procurar">Procurar</button></td>
            </tr>
        </table>
    </form>
        
    <form action="contatosInsert.php" method="post">
        <table>
            <tr>
                <td colspan="2"><button id="botao" name="Cadastrar">Cadastro</button></td>
            </tr>
        </table>
    </form>
        
    <form action="AgendaContatosSelect.php" method="post">
        <table>
            <tr>
                <td colspan="2"><button id="botao" type="submit" name="voltar">Voltar</button></td>
            </tr>
        </table>
    </form>

    <table>
        <tr>
            <td colspan="2"><a href="logoff.php"><button id="botao" type="button" name="sair">Sair</button></a></td>
        </tr>
    </table>

    <div class = iconeChat>
        <a href = "chat.php"><button><i class='bx bxs-message-dots'></i></button></a>
    </div>

    <div class = iconePerfil>
        <a href = "perfil.php"><button><i class='bx bxs-user-rectangle'></i></i></button></a>
    </div>

    <form action="" method="post">
        
    <?php
    extract($_POST);
    
    if (isset($_POST["buscar"])) {
        include_once("conect.php");
        $obj = new conect();
        $resultado = $obj->conectarBanco();

        $sql = "SELECT imagem, nome, endereco, telefone, email, celular, id FROM Contatos WHERE nome like lower('".$_POST["letra"]."%') AND Contatos_idfk = ".$_SESSION["id"].";";
        $executado = $resultado->prepare($sql);

        if ($executado->execute()) {
            $i=0;
            echo '
            <table>
                <tr>
                    <th>imagem</th>
                    <th>Nome</th>
                    <th>Endereco</th>
                    <th>Telefone</th>
                    <th>Email</th>
                    <th>Celular</th>
                    <th>Ações</th>
                </tr>';
            
            while ($linha = $executado->fetch(PDO::FETCH_ASSOC)) {
                echo '
                <tr>
                    <td><img width="35px" src="'.$linha['imagem'].'"/></td>
                    <td>'.$linha['nome'].'</td>
                    <td>'.$linha['endereco'].'</td>
                    <td>'.$linha['telefone'].'</td>
                    <td>'.$linha['email'].'</td>
                    <td>'.$linha['celular'].'</td>

                    <td>
                        <a href="ContatosUpdate.php?id='.$linha['id'].'"><button type="button">Atualizar</button></a>
                        <form action="contatosAgendaDelete.php" method="post" style="display:inline;">
                            <input type="hidden" name="deletar_id" value="'.$linha['id'].'">
                            <button type="submit" onclick="return confirm(\'Tem certeza que deseja deletar este contato?\');">Deletar</button>
                        </form>
                    </td>
                </tr>';
            }
            echo '</table>';
        } else {
            echo "Erro ao carregar os contatos.";
        }
    }

    if (isset($_POST['deletar_id'])) {
        include_once("conect.php");
        $obj = new conect();
        $resultado = $obj->conectarBanco();

        $deletar_id = $_POST['deletar_id'];
        $sql_delete = "DELETE FROM Contatos WHERE id = :id";
        $stmt = $resultado->prepare($sql_delete);
        $stmt->bindParam(':id', $deletar_id, PDO::PARAM_INT);
        if ($stmt->execute()) {
            echo "Contato deletado com sucesso.";
        } else {
            echo "Erro ao deletar o contato.";
        }
    }

    if (isset($_POST["procurar"])) {
        include_once("conect.php");
        $obj = new conect();
        $resultado = $obj->conectarBanco();

        $sql = "SELECT imagem, nome, endereco, telefone, email, celular, id FROM Contatos WHERE Contatos_idfk = ".$_SESSION["id"].";";
        $executado = $resultado->prepare($sql);

        if ($executado->execute()) {
            $i=0;
            echo '
            <table>
                <tr>
                    <th>imagem</th>
                    <th>Nome</th>
                    <th>Endereco</th>
                    <th>Telefone</th>
                    <th>Email</th>
                    <th>Celular</th>
                    <th>Ações</th>
                </tr>';
            
            while ($linha = $executado->fetch(PDO::FETCH_ASSOC)) {
                echo '
                <tr>
                    <td><img width="35px" src="'.$linha['imagem'].'"/></td>
                    <td>'.$linha['nome'].'</td>
                    <td>'.$linha['endereco'].'</td>
                    <td>'.$linha['telefone'].'</td>
                    <td>'.$linha['email'].'</td>
                    <td>'.$linha['celular'].'</td>

                    <td>
                        <a href="ContatosUpdate.php?id='.$linha['id'].'"><button type="button">Atualizar</button></a>
                        <form action="contatosAgendaDelete.php" method="post" style="display:inline;">
                            <input type="hidden" name="deletar_id" value="'.$linha['id'].'">
                            <button type="submit" onclick="return confirm(\'Tem certeza que deseja deletar este contato?\');">Deletar</button>
                        </form>
                    </td>
                </tr>';
            }
            echo '</table>';
        } 
    }
    ?>
    
    </form>

</body>
</html>

<?php
    session_name('iniciar');
    session_start();
    
    include_once("conect.php");
    $obj = new conect();
    $resultado = $obj->conectarBanco();

    $sql = "SELECT nomeUsuario, email, login, imagem FROM Usuario WHERE id = :id";
    
    $query = $resultado->prepare($sql);
    $query->bindParam(':id', $_SESSION['id']);
    if($query->execute())
{
    while($user = $query->fetch(PDO::FETCH_ASSOC))
    {
        $users[0] = $user;
    }
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSSagenda/perfil.css">
    <title>Página de Perfil da Agenda</title>
</head>
<body>

    <header>
        <button id="btn-menu"><i class='menu bx bx-menu'></i></button>
        <h1>Seu Perfil</h1>
    </header>

    <div class="container">

        <div class="container-info">
            <i class='perfil bx bxs-user'></i>
            <form action="pagPerfil.php">
                <input id="InputNome" type="text" placeholder="Nome Usuário" value="<?= $users[0]['nomeUsuario'] ?>">
                <input id="InputEmail" type="text" placeholder="Email" value="<?= $users[0]['email'] ?>">
                <input id="InputLogin" type="text" placeholder="Login" value="<?= $users[0]['login'] ?>">
                <input id="InputImagem" type="file" placeholder="Imagem de Perfil" value="<?= $users[0]['imagem'] ?>">
                <button type="button" id="btn-edita">Editar Informações</button>
                <button id="btn-edita" type="button" onclick="window.location.href='logoff.php'">Sair</button>
            </form>
        </div>
    </div>

</body>
</html>

<?php

include_once("conect.php");
$obj = new conect();
$resultado = $obj->conectarBanco();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_contato'])) {
    $id = $_POST['id'];
    $nomeUsuario = $_POST['nomeUsuario'];
    $senha = $_POST['senha'];
    $email = $_POST['email'];
    $login = $_POST['login'];
 
    echo $sql = "UPDATE Contatos SET nomeUsuario='".$_POST["nomeUsuario"]."', email='".$_POST["email"]."',login='".$_POST["login"]."',cimagem='".$_POST["imagem"]."' WHERE id=".$id.";";
    $executado = $resultado->prepare($sql);
    $executado->execute();

    echo "Contato atualizado com sucesso!";
    exit();
}
?>
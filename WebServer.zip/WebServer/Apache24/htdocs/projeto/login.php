<?php
session_name('iniciar');
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST["Entrar"])) {
    include_once("connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    $sql = "SELECT id, email, senha FROM Login1 WHERE email = :email AND senha = :senha";
    $query = $resultado->prepare($sql);
    
    $hashedPassword = md5($_POST["password"]);

    $query->bindParam(':email', $_POST["email"]);
    $query->bindParam(':senha', $hashedPassword);

    if ($query->execute()) {
        $linha = $query->fetch(PDO::FETCH_ASSOC);
        if ($linha) {
            $_SESSION["cadastro"] = TRUE;
            $_SESSION["id"] = $linha["id"];
            header("Location: pagInicial.php");
            exit();
        } else {
            $error_message = "Usuário e senha não existem, verifique!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../projeto/CSSprojeto/login.css">
    <title>Login</title>
</head>
<body>
    <header class="login"></header>

    <div class="titulo">
        <h1>LOGIN</h1>
    </div>

    <form method="post" action="login.php">
        <div class="container">
            <div class="input-group">
                <label for="email">Email:</label><br>
                <i class='bx bxs-user-circle'></i>
                <input type="email" id="email" name="email" required><br>
            </div>
            
            <div class="input-group">
                <label for="password">Senha:</label><br>
                <i class='bx bxs-lock-alt'></i>
                <input type="password" id="password" name="password" required>
            </div>
            
            <a class="link" href="AgendaUsuariosSelect.php">Esqueci a senha</a>

            <button type="submit" name="Entrar">Entrar</button>
            <button type="button" onclick="window.location.href='cadastro.php'">Cadastrar</button>
        </div>
    </form>

    <?php if (isset($error_message)): ?>
        <div class="error"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <footer></footer>
</body>
</html>

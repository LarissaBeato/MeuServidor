<?php
session_name('iniciar');
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atualizar Contato</title>
    <link rel="stylesheet" href="CSSagenda/usuarioInsert.css">
</head>

<body>

<div class="container">
    <form method="post" action="usuarioInsert.php">
        <div class="input-group">
            <label for="NomeUsuario">Nome de Usuário:</label>
            <input type="text" id="NomeUsuario" name="NomeUsuario" required>
        </div>

        <div class="input-group">
            <label for="senha">Senha:</label>
            <input type="password" id="senha" name="senha" required>
        </div>

        <div class="input-group">
            <label for="email">Email:</label>
            <input type="text" id="email" name="email" required>
        </div>

        <div class="input-group">
            <label for="login">Login:</label>
            <input type="text" id="login" name="login" required>
        </div>

        <button type="submit" name="enviar">Enviar</button>
        <div style="margin-top: 15px;">
            <a href="login.php"><button type="button" class="botao2">Voltar para Login</button></a>
        </div>
    </form>
</div>

</body>
</html>

<?php

if (isset($_POST["enviar"])) {
    include_once("conect.php");
    $obj = new conect();
    $resultado = $obj->conectarBanco();

    $email = $_POST["email"];
    $login = $_POST["login"];

    // Verificar se e-mail ou login já existem
    $sqlCheck = "SELECT COUNT(*) FROM Usuario WHERE email = :email OR login = :login";
    $queryCheck = $resultado->prepare($sqlCheck);
    $queryCheck->execute([':email' => $email, ':login' => $login]);
    $userExists = $queryCheck->fetchColumn();

    if ($userExists > 0) {
        echo "<script>alert('Este e-mail ou login já está cadastrado!');</script>";
    } else {
        $nomeUsuario = $_POST["NomeUsuario"];
        $senha = md5($_POST["senha"]);
        $loginCriptografado = md5($login);

        $sql = "INSERT INTO Usuario (NomeUsuario, senha, email, login, ativo) VALUES (:nomeUsuario, :senha, :email, :login, TRUE)";
        $query = $resultado->prepare($sql);

        $query->bindParam(':nomeUsuario', $nomeUsuario);
        $query->bindParam(':senha', $senha);
        $query->bindParam(':email', $email);
        $query->bindParam(':login', $login);

        if ($query->execute()) {
            echo "<script>alert('Usuário cadastrado com sucesso!'); window.location.href='login.php';</script>";
        } else {
            echo "<script>alert('Erro ao cadastrar.');</script>";
        }
    }

    unset($_POST["enviar"], $_POST["NomeUsuario"], $_POST["senha"], $_POST["email"], $_POST["login"]);
}
?>

<html>

<body>
<form method="post" action="pgn.php">
    <label for="name">Nome:</label><br>
    <input type="name" id="name" name="name" required ><br>
    <label for="password">Senha:</label><br>
    <input type="password" id="password" name="password" required>
   
    <button type="submit" name ="Entrar">Entrar</button>

</form> 

</body>
</html>

<?php
    extract($_POST);
    if(isset($_POST["Entrar"])){
        include_once("conect.php");
        $obj = new conect();
        $resultado = $obj-> conectarBanco();

    }


?>

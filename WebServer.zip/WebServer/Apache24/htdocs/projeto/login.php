<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../projeto/CSSprojeto/login.css">
    <title>Login</title>
</head>
<body>
    <header class ="login"></header>

    <div class = "titulo">
        <h1>LOGIN</h1>
    </div>

    <form method="post" action="login.php">
        <div class="container">
            <div class="input-group">
                <label for="email">Email:</label><br>
                <i class='bx bxs-user-circle'></i>
                <input type="email" id="name" name="name" required><br>
            </div>
            
            <div class="input-group">
                <label for="password">Senha:</label><br>
                <i class='bx bxs-lock-alt'></i>
                <input type="password" id="password" name="password" required>
            </div>
            
            <a class = "link" href = "AgendaUsuariosSelect.php">Esqueci a senha</a>

            <button type="submit" onclick="window.location.href='pagInicial.php'" name="Entrar">Entrar</button>
            <button id="botao" type="button" onclick="window.location.href='cadastro.php'">Cadastrar</button>
        </div>
            
</form> 
<footer></footer>

</body>
</html>
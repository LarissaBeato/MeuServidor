<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../projeto/CSSprojeto/cadastro.css">
    <title>Cadastro</title>
</head>
<body>
    <header class ="cadastro"></header>

    <div class = "titulo">
        <h1>CADASTRO</h1>
    </div>

    <form method="post" action="login.php">
        <div class="container">
            <div class="input-group">
                <label for="nome">Nome Completo:</label><br>
                <input type="name" id="name" name="name" required><br>
            </div>
            
            <div class="input-group">
                <label for="telefone">Telefone:</label><br>
                <input type="tel" id="telefone" name="telefone" required>
            </div>

            <div class="input-group">
                <label for="cpf">CPF:</label><br>
                <input type="text" id="cpf" name="cpf" required>
            </div>

            <div class="input-group">
                <label for="email">Email:</label><br>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="input-group">
                <label for="password">Senha:</label><br>
                <input type="password" id="password" name="password" required>
            </div>

            <div class="input-group">
                <label for="password">Confirmar Senha:</label><br>
                <input type="password" id="password" name="password" required>
            </div>

            <button type="submit" onclick="window.location.href='login.php'" name="Entrar">Enviar</button>
            
        </div>

    </body>
</html>